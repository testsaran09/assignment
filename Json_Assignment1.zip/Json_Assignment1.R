#install.packages("rjson")
library("rjson")



args = commandArgs(trailingOnly=TRUE)

if (length(args)<2) {
  stop("Usage: [path to your program] [input file path] [output file path]\n", call.=FALSE)
} 


# Give the data file name to the function.
#result <- fromJSON(file = "D:\\sample.json")
result <- fromJSON(file = args[1])


df <- lapply(result, function(play) # Loop through each "play"
{
  # Convert each group to a data frame.
  # This will have 5 elements each time
  data.frame(matrix(unlist(play), ncol=5, byrow=T))
})

# Now you have a list of data frames, connect them together in
# one single dataframe
df <- do.call(rbind, df)

# Make column names nicer, remove row names
colnames(df) <- names(result[[1]][[1]])
rownames(df) <- NULL


#write the output data frame into file
write.table(df,args[2],sep="\t",row.names=FALSE)

