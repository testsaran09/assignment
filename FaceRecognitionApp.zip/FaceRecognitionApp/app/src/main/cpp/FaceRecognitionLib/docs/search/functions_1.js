var searchData=
[
  ['euclideandist',['euclideanDist',['../class_facebase.html#a3b8a3a7e7e6dbed35c74b50df124abc8',1,'Facebase']]],
  ['euclideandistface',['euclideanDistFace',['../class_facebase.html#a13b1f4827eb8d5c746bb1ff5713ee03e',1,'Facebase']]]
];
