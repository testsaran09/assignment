var searchData=
[
  ['calculatematches',['calculateMatches',['../main_8cpp.html#aca182b6cb6c5a18d4ef4156a2f31090a',1,'main.cpp']]],
  ['compute',['compute',['../class_l_d_a.html#ae2cb8a65501e1da69ef7334ef030bb3e',1,'LDA::compute()'],['../class_p_c_a.html#a995bea6518105832e484f99439a272b7',1,'PCA::compute()']]]
];
