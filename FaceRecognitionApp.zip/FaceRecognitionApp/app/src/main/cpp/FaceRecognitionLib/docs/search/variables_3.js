var searchData=
[
  ['fisherfaces',['fisherfaces',['../main_8cpp.html#a477ffd416d99dcf7c84fb38d7305ab6f',1,'main.cpp']]]
];
