var searchData=
[
  ['train',['train',['../class_eigenfaces.html#a3e8a52e8e21ba0d4d7eaf4589b5b58c6',1,'Eigenfaces::train()'],['../class_fisherfaces.html#ac6ef6809d753e757a483a83492b67cd5',1,'Fisherfaces::train()']]]
];
