var searchData=
[
  ['lda',['LDA',['../class_l_d_a.html',1,'']]],
  ['lda_2ecpp',['LDA.cpp',['../_l_d_a_8cpp.html',1,'']]],
  ['lda_2eh',['LDA.h',['../_l_d_a_8h.html',1,'']]]
];
