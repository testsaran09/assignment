var searchData=
[
  ['facebase',['Facebase',['../class_facebase.html',1,'']]],
  ['fisherfaces',['Fisherfaces',['../class_fisherfaces.html',1,'']]]
];
