var searchData=
[
  ['lda',['LDA',['../class_l_d_a.html',1,'']]]
];
